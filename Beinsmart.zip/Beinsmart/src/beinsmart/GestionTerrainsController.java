/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beinsmart;

import Entities.Terrain;
import Service.ServiceTerrain;
import Utils.MaConnexion;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.function.Predicate;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author lenovo
 */
public class GestionTerrainsController implements Initializable {

    @FXML
    private Button btnRetourTerrain;
    @FXML
    private TextField tfidedit;
    @FXML
    private Button btnModifier;
    @FXML
    private TableView<Terrain> coachTabe;
    @FXML
    private TableColumn<Terrain, Integer> idCol;
    @FXML
    private TableColumn<Terrain, String> nomCol;
    @FXML
    private TableColumn<Terrain ,String> adresseCol;
    
       @FXML
    private TableColumn<Terrain, String> typeSportCol;
    @FXML
    private TableColumn<Terrain, String> ressourcesCol;
    @FXML
    private Button btnAjouter;
    @FXML
    private Button btnAnnuler;
    @FXML
    private Button btnSupprimer;
    @FXML
    private TextField tfNomt;
    @FXML
    private TextField tfAdr;
 
    @FXML
    private Button ActualiserButton;
    @FXML
    private TextField tfressources;
    @FXML
    private TextField tftypeSport;
    @FXML
    private Button btnrecherche;
    @FXML
    private TextField tfrecherche;
    @FXML
    private ImageView LogoImageView;
    @FXML
    private Button btnchart;

   
     

    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    public void ShowTerrains(){
        ServiceTerrain t = new ServiceTerrain();

        ObservableList<Terrain> List = t.AffichTerrain();
       idCol.setCellValueFactory(new PropertyValueFactory<Terrain, Integer>("id") );
       nomCol.setCellValueFactory(new PropertyValueFactory<Terrain, String>("nomT") );
       adresseCol.setCellValueFactory(new PropertyValueFactory<Terrain, String>("Adresse") );
         typeSportCol.setCellValueFactory(new PropertyValueFactory<Terrain, String>("type_sport") );
         ressourcesCol.setCellValueFactory(new PropertyValueFactory<Terrain, String>("ressources"));
          coachTabe.setItems(List);
        }



    @FXML
    private void Ajouter(ActionEvent event) {
        
        
        Terrain t =new Terrain();
             ServiceTerrain st=new ServiceTerrain();
     String nom=tfNomt.getText();
     String adresse=tfAdr.getText();
        String type_sport=tftypeSport.getText();
     String ressources=tfressources.getText();
      t.setNomT(nom);
      t.setAdresse(adresse);
      t.setRessources(ressources);
      t.setType_sport(type_sport);

      
      if (nom.isEmpty()||adresse.isEmpty()||type_sport.isEmpty()||ressources.isEmpty()){
     
     Alert alert =new Alert(Alert.AlertType.ERROR);
     alert.setHeaderText(null);
     alert.setContentText("veuillez insérer toutes les données nécéssaires");
     alert.showAndWait();
     
     }else{
    
     st.AjoutTerrain(t);
   
     }
    }
    @FXML
    private void Modifier(ActionEvent event) {
           Terrain t = new Terrain();
           ServiceTerrain st= new ServiceTerrain();
           int IDValue=Integer.parseInt(tfidedit.getText());
           t.setId(IDValue);
           st.ModifTerrain(t);
           
         String nom=tfNomt.getText();
     String adresse=tfAdr.getText();
        String type_sport=tftypeSport.getText();
     String ressources=tfressources.getText();
      t.setNomT(nom);
      t.setAdresse(adresse);
      t.setRessources(ressources);
      t.setType_sport(type_sport);

       st.ModifTerrain(t);
      ShowTerrains();
    }

    

    @FXML
    private void Supprimer(ActionEvent event) {
        
            ServiceTerrain st= new ServiceTerrain();
            Terrain t=new Terrain();
            int IDValue=Integer.parseInt(tfidedit.getText());
            t.setId(IDValue);
            st.SupprTerrain(t);
          //  Coach c=coachTabe.getSelectionModel().getSelectedItem();
          //  sc.SupprCoach(c);
       ShowTerrains();
    }



    @FXML
    private void ActualiserTable(ActionEvent event) {
         ServiceTerrain st = new ServiceTerrain();
                ShowTerrains();
    }
    
@FXML
    private void Annuler(ActionEvent event) {
        tfNomt.setText(null);
        tfAdr.setText(null);
        tfressources.setText(null);
        tftypeSport.setText(null);
         tfidedit.setText("");
                 tfrecherche.setText("");
    }

    
    @FXML
    private void RetourTerrain(ActionEvent event) throws Exception{
             Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
    Stage window=(Stage) btnRetourTerrain.getScene().getWindow();
    window.setScene(new Scene(root,1035,900));
    
    }

    @FXML
    private void rechercher(ActionEvent event) {
         ServiceTerrain st = new ServiceTerrain();
            ObservableList<Terrain> List = st.AffichTerrain();
           FilteredList<Terrain> FilteredTerrain = new FilteredList<>(List,e-> true);
        tfrecherche.textProperty().addListener((Observablevalue,OldValue,NewValue)->{
            FilteredTerrain.setPredicate((Predicate<? super Terrain>) Terrain ->{
                if (NewValue ==null || NewValue.isEmpty()){
                    return true;
                }
               
                
                String lowerCaseFilter  = NewValue.toLowerCase();
                 
                if(Terrain.getAdresse().toLowerCase().contains(lowerCaseFilter)){
                    return true;
                }else if(Terrain.getNomT().toLowerCase().contains(lowerCaseFilter)){
                    return true;
                }else if(Terrain.getRessources().toLowerCase().contains(lowerCaseFilter)){
                    return true;
                }  else if(Terrain.getType_sport().toLowerCase().contains(lowerCaseFilter)){
                    return true;
                }else if(String.valueOf(Terrain.getId()).contains(NewValue)){
                    return true;
                }
                return false;
                
            });
            SortedList<Terrain> SortedCoach = new SortedList<> (FilteredTerrain);
            SortedCoach.comparatorProperty().bind(coachTabe.comparatorProperty());
                    coachTabe.setItems(SortedCoach);
        }
        
        
        );
    }
 
   
    @FXML
     private void AffichChart(ActionEvent event) throws IOException {
        
         
           Parent root = FXMLLoader.load(getClass().getResource("Stat.fxml"));
    Stage window=(Stage) btnRetourTerrain.getScene().getWindow();
    window.setScene(new Scene(root,1000,600));
//            XYChart.Series series=new XYChart.Series();
//        series.getData().add(new XYChart.Data("Club des Princes",2));
//series.getData().add(new XYChart.Data("Terrain Lake Club",7));
//series.getData().add(new XYChart.Data("The Hills Academy",8));
//series.getData().add(new XYChart.Data("Star Sport Academy",1));
//series.getData().add(new XYChart.Data("Olympico Staduim",5));
//series.getData().add(new XYChart.Data("Olympysky Club",10));
//series.getData().add(new XYChart.Data("Marselone",3));
//
//
//        LineChart.getData().addAll(series);

                 
    


//
                 //PieChart dataset=new PieChart();

    //     JFreeChart chart=createChart(dataset);
         
         
     /*   try{
            String query ="SELECT `type_sport`, `nomT` FROM `terrain` ";
            JDBCCategoryDataset dataset=new JDBCCategoryDataset(MaConnexion.getInstance(),query);
            
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(null, e);
        }*/
    }

    
    
    
    
    

}
