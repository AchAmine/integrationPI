 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beinsmart;

import Entities.Coach;
import Service.ServiceCoach;
import java.awt.Desktop;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.function.Predicate;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author lenovo
 */
public class GestionCoachsController implements Initializable {

    private Button btnRetourCoach;
    private BorderPane mainPane;
    @FXML
    private TextField tfidedit;
    @FXML
    private Button btnModifier;
       @FXML
    private TableColumn<Coach, Integer> idCol;
    @FXML
    private TableColumn<Coach, String> nomCol;
    @FXML
    private TableColumn<Coach, String> prenomCol;
 
    @FXML
    private Button btnAjouter;
    @FXML
    private Button btnAnnuler;
    @FXML
    private TextField tfNom;
    @FXML
    private TextField tfPrenom;
   
    @FXML
    private TextField tfMobile;
    @FXML
    private TextField tfAdresse;
    @FXML
    private Button btnSupprimer;
    @FXML
    private Button btnRetourTerrain;
    @FXML
    private TableView<Coach> coachTabe;
    @FXML
    private Button ActualiserButton;
    @FXML
    private TextField tfnaiss;
    @FXML
    private TextField tfrecherche;
    @FXML
    private Button btnrecherche;
    @FXML
    private ImageView LogoImageView;
    @FXML
    private TextField ImgPath;
    @FXML
    private Button imgButton;

    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
     
    private ImageView PreuvIMG;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
      
      ShowCoachs();
        Ajout();
        
    }    
    
    
    
    
    
    public void ShowCoachs(){
        ServiceCoach sc = new ServiceCoach();

        ObservableList<Coach> List = sc.AffichCoach();
       idCol.setCellValueFactory(new PropertyValueFactory<Coach, Integer>("id") );
       nomCol.setCellValueFactory(new PropertyValueFactory<Coach, String>("nom") );
       prenomCol.setCellValueFactory(new PropertyValueFactory<Coach, String>("prenom") );
      
     
          coachTabe.setItems(List);
          coachTabe.setRowFactory(rc -> {
            TableRow<Coach> row = new TableRow<>();
            row.setOnMouseClicked((MouseEvent event) -> {
                if (event.getClickCount() == 2 && (!row.isEmpty())) {
                    
                    Coach c =coachTabe.getSelectionModel().getSelectedItem();
                    Node node = (Node) event.getSource();
                    Stage stage = (Stage) node.getScene().getWindow();
                    
                    FXMLLoader loader = new FXMLLoader ();
                    loader.setLocation(getClass().getResource("DetailsCoach.fxml"));
                    try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(GestionCoachsController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    DetailsCoachController dc = loader.getController();
                    dc.AffichDetCoach(c);
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show();
                    
                }
            }); return row;
                });
        }
    
    
    
    
    
    
   @FXML
    private void Modifier(ActionEvent event) {
          Coach c = new Coach();
           ServiceCoach sc= new ServiceCoach();
           int IDValue=Integer.parseInt(tfidedit.getText());
           c.setId(IDValue);
           sc.ModifierCoach(c);
           
           String nom=tfNom.getText();
     String prenom=tfPrenom.getText();
     String adresse=tfAdresse.getText();
        String tel=tfMobile.getText();
     String naiss=tfnaiss.getText();
      c.setNom(nom);
      c.setPrenom(prenom);
      c.setAdresse(adresse);
      c.setTel(tel);
      c.setNaiss(naiss);
       sc.ModifierCoach(c);
      ShowCoachs();
            /*
       String nom=tfNom.getText();
       String prenom=tfPrenom.getText();
       String adresse=tfAdresse.getText();
       String tel=tfMobile.getText();
       String naiss=tfnaiss.getText();
       sc.ModifierCoach(c);
       
       ShowCoachs();*/
    }
 File file ;
    private Desktop desktop = Desktop.getDesktop();
    
    private void Ajout() {
        
        
        Coach c =new Coach();
             ServiceCoach sc=new ServiceCoach();
     
       FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("image","*.png","*.jpg","*.gif"));
      
        imgButton.setOnAction((ActionEvent event)-> {
              
                 file = fileChooser.showOpenDialog(imgButton.getScene().getWindow());
                            
                            ImgPath.setText(file.getAbsolutePath());
                            c.setURLImg(file.getAbsolutePath());

                
             
         });
     
        
        btnAjouter.setOnAction((ActionEvent ev)-> {
    /* if (nom.isEmpty()||prenom.isEmpty()||naiss.isEmpty()||adresse.isEmpty()||tel.isEmpty()){
     
     Alert alert =new Alert(Alert.AlertType.ERROR);
     alert.setHeaderText(null);
     alert.setContentText("veuillez insérer toutes les données nécéssaires");
     alert.showAndWait();
     
     }else{ */
    String nom=tfNom.getText();
     String prenom=tfPrenom.getText();
     String adresse=tfAdresse.getText();
        String tel=tfMobile.getText();
     String naiss=tfnaiss.getText();
     String url=ImgPath.getText();
      c.setNom(nom);
      c.setPrenom(prenom);
      c.setAdresse(adresse);
      c.setTel(tel);
      c.setNaiss(naiss);
      c.setURLImg(ImgPath.getText());
         
                if (nom.isEmpty()||prenom.isEmpty()||naiss.isEmpty()||adresse.isEmpty()||tel.isEmpty()){
     
     Alert alert =new Alert(Alert.AlertType.ERROR);
     alert.setHeaderText(null);
     alert.setContentText("veuillez insérer toutes les données nécéssaires");
     alert.showAndWait();
     
     }else{ 
     sc.AjoutCoach(c);
                }
     });
                
                }
    @FXML
    private void Annuler(ActionEvent event) {
        tfNom.setText(null);
        tfPrenom.setText(null);
           tfAdresse.setText(null);
              tfMobile.setText(null);
                 tfnaiss.setText(null);
                 tfidedit.setText("");
                 tfrecherche.setText("");
    }
  
    
   
    @FXML
    private void Supprimer(ActionEvent event) {
            
            ServiceCoach sc= new ServiceCoach();
            Coach c=new Coach();
            int IDValue=Integer.parseInt(tfidedit.getText());
            c.setId(IDValue);
            sc.SupprCoach(c);
          //  Coach c=coachTabe.getSelectionModel().getSelectedItem();
          //  sc.SupprCoach(c);
       ShowCoachs();
       
    }

    @FXML
    private void RetourTerrain(ActionEvent event) throws IOException {
                Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
    Stage window=(Stage) btnRetourTerrain.getScene().getWindow();
    window.setScene(new Scene(root,1035,900));
    }

    @FXML
    private void ActualiserTable(ActionEvent event) {
         ServiceCoach c = new ServiceCoach();
                ShowCoachs();
                
    }

    @FXML
    private void rechercher(ActionEvent event) {
        ServiceCoach sc = new ServiceCoach();
            ObservableList<Coach> List = sc.AffichCoach();
           FilteredList<Coach> FilteredCoach = new FilteredList<>(List,e-> true);
        tfrecherche.textProperty().addListener((Observablevalue,OldValue,NewValue)->{
            FilteredCoach.setPredicate((Predicate<? super Coach>) Coach ->{
                if (NewValue ==null || NewValue.isEmpty()){
                    return true;
                }
               
                
                String lowerCaseFilter  = NewValue.toLowerCase();
                 
                if(Coach.getAdresse().toLowerCase().contains(lowerCaseFilter)){
                    return true;
                }else if(Coach.getNaiss().toLowerCase().contains(lowerCaseFilter)){
                    return true;
                }else if(Coach.getPrenom().toLowerCase().contains(lowerCaseFilter)){
                    return true;
                }  else if(Coach.getNom().toLowerCase().contains(lowerCaseFilter)){
                    return true;
                }else if(Coach.getTel().toLowerCase().contains(lowerCaseFilter)){
                    return true;
                
                }else if(String.valueOf(Coach.getId()).contains(NewValue)){
                    return true;
                }
                return false;
                
            });
            SortedList<Coach> SortedCoach = new SortedList<> (FilteredCoach);
            SortedCoach.comparatorProperty().bind(coachTabe.comparatorProperty());
                    coachTabe.setItems(SortedCoach);
        }
        
        
        );
    
   

    }
    
     
     
     
private String sexe;
    private void homme(MouseEvent event) {
       sexe ="homme";
    }

    private void femme(MouseEvent event) {
        sexe="femme";
    }


   

    

    
    
     
    
}
