/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beinsmart;

import Entities.Terrain;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author lenovo
 */


public class JFreeChartController implements Initializable {

    @FXML
    private Button btnRetourTerrain;
    @FXML
    public LineChart<?, ?> LineChart;
    @FXML
    private NumberAxis y; 
    @FXML
    private CategoryAxis x;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        XYChart.Series series=new XYChart.Series();
  /*      series.getData().add(new XYChart.Data(2,"Terrain Lake Club"));
series.getData().add(new XYChart.Data(7,"Terrain Lake Club"));
series.getData().add(new XYChart.Data(8,"Terrain Lake Club"));
*/
        LineChart.getData().addAll(series);
        
        
                

    }    
    @FXML
    private void RetourTerrain(ActionEvent event) throws Exception{
             Parent root = FXMLLoader.load(getClass().getResource("GestionTerrains.fxml"));
    Stage window=(Stage) btnRetourTerrain.getScene().getWindow();
    window.setScene(new Scene(root,600,400));
    
    }
}
