/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beinsmart;

import Entities.Coach;
import Service.ServiceCoach;
import java.awt.image.BufferedImage;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.image.ImageView;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.stage.Stage;
import javax.imageio.ImageIO;

/**
 * FXML Controller class
 *
 * @author lenovo
 */
public class DetailsCoachController implements Initializable {

    @FXML
    private ImageView LogoImageView;
    @FXML
    private TextArea taNom;
    @FXML
    private TextArea taPrenom;
    @FXML
    private TextArea taNaiss;
    @FXML
    private TextArea tfAdr;
    @FXML
    private TextArea taTel;
    @FXML
    private ImageView PreuvIMG;
    @FXML
    private Button btnRetourTerrain;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    
    
     public void AffichDetCoach(Coach c){
         ServiceCoach sc = new ServiceCoach();
        c = sc.details(c.getId());
        taPrenom.setText(c.getPrenom());
        taNom.setText(c.getNom());
        taTel.setText(c.getTel());
                taNaiss.setText(c.getNaiss());
                        tfAdr.setText(c.getAdresse());
                        


    
        String path = c.getURLImg();
        BufferedImage BfImg = null;
        try {
           
            BfImg = ImageIO.read(new FileInputStream(path));
            
        } catch (Exception ex) {
           System.out.println("Failed to load image");
           System.out.println(ex);
        }
        WritableImage wr = null;
        if (BfImg != null) {
            wr = new WritableImage(BfImg.getWidth(), BfImg.getHeight());
            PixelWriter pw = wr.getPixelWriter();
            for (int x = 0; x < BfImg.getWidth(); x++) {
                for (int y = 0; y < BfImg.getHeight(); y++) {
                    pw.setArgb(x, y, BfImg.getRGB(x, y));
                }
            }
        }
        
        PreuvIMG.setImage(wr);
        
    }

    @FXML
    private void RetourTerrain(ActionEvent event) throws IOException {
                Parent root = FXMLLoader.load(getClass().getResource("GestionCoachs.fxml"));
    Stage window=(Stage) btnRetourTerrain.getScene().getWindow();
    window.setScene(new Scene(root,1035,900));
    }
}
