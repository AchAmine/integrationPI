/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import Entities.Coach;
import Services.ICoach;
import Utils.MaConnexion;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author lenovo
 */
public class ServiceCoach implements ICoach{
Connection cnx;

    public ServiceCoach() {
        cnx=MaConnexion.getInstance().getConnection();
        
    }

    @Override
    public void AjoutCoach(Coach c) {
try {
            Statement stm =cnx.createStatement();      
             // String query="INSERT INTO `coach`( `nom`, `prenom`, `tel`, `naiss`, `adresse`,`image`)  VALUES (?,?,?,?,?,?,?)";

  String query="INSERT INTO `coach`( `nom`, `prenom`, `tel`, `naiss`, `adresse`,`image`)  VALUES ("+'"'+c.getNom()+'"'+","+'"'+c.getPrenom()+'"'+","+'"'+c.getTel()+'"'+","+'"'+c.getNaiss()+'"'+","+'"'+c.getAdresse()+'"'+","+'"'+c.getURLImg()+'"'+")";

           // String query="INSERT INTO `coach`( `nom`, `prenom`, `tel`, `naiss`, `adresse`)  VALUES ("+'"'+c.getNom()+'"'+","+'"'+c.getPrenom()+'"'+","+'"'+c.getTel()+'"'+","+'"'+c.getNaiss()+'"'+","+'"'+c.getAdresse()+'"'+")";
           PreparedStatement pst=cnx.prepareStatement(query);
           
            pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ServiceCoach.class.getName()).log(Level.SEVERE, null, ex);
        }    }

    
    @Override
    public ObservableList<Coach> AffichCoach() {
  ObservableList<Coach> Coachs = FXCollections.observableArrayList();

        try {
            Statement stm =cnx.createStatement();
            String query="SELECT * FROM `coach`  ";

            ResultSet rst =stm.executeQuery(query);
            while (rst.next())
            {
                Coach c = new Coach();
                c.setId(rst.getInt("id"));
                c.setNom(rst.getString("nom"));
                c.setPrenom(rst.getString("prenom"));
                c.setNaiss(rst.getString("naiss"));
                
                
                InputStream is=rst.getBinaryStream("image");
                
                
                c.setAdresse(rst.getString("adresse"));
                c.setTel(rst.getString("tel"));
                
                
                c.setURLImg(rst.getString("image"));
                
                
                Coachs.add(c);
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(ServiceCoach.class.getName()).log(Level.SEVERE, null, ex);
        }
            return Coachs;    }

    @Override
    public void SupprCoach(Coach c) {
         try {
                 String query = "delete from `coach`  where id="+c.getId();
                 PreparedStatement pst = cnx.prepareStatement(query);
                 pst.execute();
             } catch (SQLException ex) {
                 Logger.getLogger(ServiceCoach.class.getName()).log(Level.SEVERE, null, ex);
             }    }

    
    
    @Override
    public void ModifierCoach(Coach c) {
try {   
String query ="UPDATE `coach` SET "
        + "`nom`='"+c.getNom()+"',"
                + "`prenom`='"+c.getPrenom()+"',"
                + "`naiss`='"+c.getNaiss()+"',"
                + "`tel`='"+c.getTel()+"',"
                + "`adresse`='"+c.getAdresse()+ 
                "'WHERE id="+c.getId() ;
  //  String query = "UPDATE `coach` SET `nom`= '" + c.getNom() + "',`prenom`='" + c.getPrenom() + "',`tel`='" + c.getTel() + "',`naiss`='" + c.getNaiss() + "',`adresse`='" + c.getAdresse()+"' WHERE id=" + c.getId();

 PreparedStatement pst = cnx.prepareStatement(query);
               pst.execute();
             } catch (SQLException ex) {
                 Logger.getLogger(ServiceCoach.class.getName()).log(Level.SEVERE, null, ex);
             }    }
    
    
    
    

    @Override
    public ObservableList<Coach> RechercherCoach(String CoachN) {
                ObservableList<Coach>Coachs = FXCollections.observableArrayList();

String query="SELECT `id`, `nom`, `prenom`, `tel`, `naiss`, `adresse`,`image` FROM `coach` where nom= "+CoachN ;
    
    try {
            Statement stm = cnx.createStatement();
               ResultSet rst =stm.executeQuery(query);
            while (rst.next())
            {
                Coach c = new Coach();
                c.setId(rst.getInt("id"));
                c.setNom(rst.getString("nom"));
                c.setPrenom(rst.getString("prenom"));
                c.setNaiss(rst.getString("naiss"));
                c.setAdresse(rst.getString("adresse"));
                c.setTel(rst.getString("tel"));
                Coachs.add(c);
            }
        }
        catch(SQLException ex) {
            Logger.getLogger(ServiceCoach.class.getName()).log(Level.SEVERE,null,ex);
        }
    
    
    return Coachs;
    
    }

    @Override
    public Coach details(int id) {
        String query = "SELECT * from coach WHERE id="+id+"";
        
        Coach c = new Coach();
                try {
           Statement stm = cnx.createStatement();
           ResultSet rst = stm.executeQuery(query);
           while(rst.next()) {
           c.setNom(rst.getString("nom"));
  c.setPrenom(rst.getString("prenom"));
  c.setAdresse(rst.getString("adresse"));
             c.setTel(rst.getString("tel"));
           c.setURLImg(rst.getString("image"));
           c.setNaiss(rst.getString("naiss"));
           
           
           }
           
       } catch (SQLException ex) {
           Logger.getLogger(ServiceCoach.class.getName()).log(Level.SEVERE, null, ex);
       }
            
           return c; 
        
    }

    
        


    }

