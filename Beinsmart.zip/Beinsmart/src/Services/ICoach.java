/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Services;

import Entities.Coach;
import java.util.List;
import javafx.collections.ObservableList;

/**
 *
 * @author lenovo
 */
public interface ICoach {
     public void AjoutCoach(Coach c);
    public ObservableList<Coach> AffichCoach();
    public void SupprCoach(Coach c);
    public void ModifierCoach(Coach c);
    public ObservableList<Coach> RechercherCoach(String CoachN);
    public Coach details(int id);
   
}
